package stack;

/**
 * A {@link LinkedStack} is a stack that is implemented using a Linked List structure
 * to allow for unbounded size.
 *
 * @param <T> the elements stored in the stack
 */
public class LinkedStack<T> implements StackInterface<T> {
	
LLNode<T> head = null;
	/**
	 * {@inheritDoc}
	 */
	@Override
	public T pop() throws StackUnderflowException {
    // TODO
		if(isEmpty())
			throw new StackUnderflowException();
		T temp = head.getData();
		head = head.getNext();
		return temp;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public T top() throws StackUnderflowException {
    // TODO
		if(isEmpty())
			throw new StackUnderflowException();
		return head.getData();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isEmpty() {
    // TODO
		return (head == null);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int size() {
    // TODO
		int count = 0;
		LLNode<T> temp = head;
		while(temp != null) {
			count++;
			temp = temp.getNext();
		}	
		return count;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void push(T elem) {
    // TODO
		LLNode<T> newElem = new LLNode<T>(elem);
		newElem.setNext(head);
		head = newElem;
	}

}
